package com.mtz.importer;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Converts a MtZ theme file into the layout used by the Themes app:
 *   .data/content/<code>/<uuid>.mrc   (component content)
 *   .data/meta/<code>/<uuid>.mrm      (JSON metadata, hash = SHA-1 of content)
 *   .data/preview/theme/<themeId>/... (preview images)
 */
public final class MtzConverter {

    public interface Progress { void onStep(String message); }

    public static final class Result {
        public String themeId;
        public File dataDir;
        public int components;
    }

    private static final String[] SUB_ORDER = {
            "wallpaper", "launcher", "statusbar", "lockscreen", "clock_2x4", "icons", "miui.systemui.plugin"};
    private static final String[] PREVIEW_ORDER = {
            "lockscreen", "launcher", "statusbar", "contact", "mms", "icons", "clock_2x4"};

    private static final Map<String, String> NAME_MAP = new HashMap<>();
    static {
        NAME_MAP.put("com.android.systemui", "statusbar");
        NAME_MAP.put("com.miui.home", "launcher");
        NAME_MAP.put("com.android.contacts", "contact");
        NAME_MAP.put("com.android.mms", "mms");
        NAME_MAP.put("framework-res", "framework");
    }

    private static final Pattern PREVIEW_NAME =
            Pattern.compile("^([a-z]{2,3}(?:_[A-Za-z0-9]{2,4})?)_(.+)\\.(png|jpg|jpeg|webp)$");

    private static final class Info {
        String version, fallbackAuthor = "", fallbackDesigner = "", fallbackTitle = "", fallbackDesc = "", adapter;
        Integer platform;
        Map<String, String> authors = new LinkedHashMap<>();
        Map<String, String> designers = new LinkedHashMap<>();
        Map<String, String> titles = new LinkedHashMap<>();
        Map<String, String> descs = new LinkedHashMap<>();
    }

    private static final class Sub {
        String code, id, hash;
        long size;
    }

    public static Result convert(File mtz, File themeRoot, Progress progress) throws Exception {
        if (progress == null) progress = m -> { };

        progress.onStep("Reading file...");
        String wholeHash = sha1(mtz);
        long wholeSize = mtz.length();

        ZipFile zf;
        try {
            zf = new ZipFile(mtz);
        } catch (IOException e) {
            throw new IOException("This is not a valid MtZ theme file");
        }
        try {
            ZipEntry descEntry = zf.getEntry("description.xml");
            Info info = descEntry != null ? parseInfo(zf.getInputStream(descEntry)) : new Info();

            // Collect components and previews
            Map<String, ZipEntry> comps = new LinkedHashMap<>();
            ZipEntry lockWall = null;
            List<ZipEntry> previews = new ArrayList<>();
            java.util.Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (e.isDirectory() || n.equals("description.xml")) continue;
                if (n.startsWith("preview/")) {
                    if (n.indexOf('/', 8) < 0) previews.add(e);
                } else if (n.equals("wallpaper/default_wallpaper.jpg")) {
                    comps.put("wallpaper", e);
                } else if (n.equals("wallpaper/default_lock_wallpaper.jpg")) {
                    lockWall = e;
                } else if (n.indexOf('/') < 0) {
                    String code = NAME_MAP.containsKey(n) ? NAME_MAP.get(n) : n;
                    comps.put(code, e);
                }
            }
            if (!comps.containsKey("lockscreen") && lockWall != null) comps.put("lockscreen", lockWall);
            if (comps.isEmpty()) throw new IOException("No theme components found in this file");

            File dataDir = new File(themeRoot, ".data");
            new File(themeRoot, ".download/.temp").mkdirs();
            String themeId = UUID.randomUUID().toString();

            // Components
            List<String> codes = new ArrayList<>(comps.keySet());
            Collections.sort(codes, orderComparator(SUB_ORDER));
            List<Sub> subs = new ArrayList<>();
            for (String code : codes) {
                progress.onStep("Saving " + code + "...");
                Sub s = new Sub();
                s.code = code;
                s.id = UUID.randomUUID().toString();
                File dir = new File(dataDir, "content/" + safe(code));
                dir.mkdirs();
                File out = new File(dir, s.id + ".mrc");
                MessageDigest md = MessageDigest.getInstance("SHA-1");
                long total = 0;
                try (InputStream in = zf.getInputStream(comps.get(code));
                     OutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[65536];
                    int r;
                    while ((r = in.read(buf)) > 0) {
                        os.write(buf, 0, r);
                        md.update(buf, 0, r);
                        total += r;
                    }
                }
                s.hash = hex(md.digest());
                s.size = total;
                subs.add(s);
            }

            // Previews
            progress.onStep("Saving previews...");
            File pdir = new File(dataDir, "preview/theme/" + themeId);
            pdir.mkdirs();
            List<String> previewNames = new ArrayList<>();
            for (ZipEntry e : previews) {
                String name = e.getName().substring(8);
                if (name.isEmpty()) continue;
                try (InputStream in = zf.getInputStream(e); OutputStream os = new FileOutputStream(new File(pdir, name))) {
                    byte[] buf = new byte[65536];
                    int r;
                    while ((r = in.read(buf)) > 0) os.write(buf, 0, r);
                }
                previewNames.add(name);
            }
            // locale -> ordered names
            Map<String, List<String>> themePrev = new LinkedHashMap<>();
            Collections.sort(previewNames, previewComparator());
            for (String name : previewNames) {
                Matcher m = PREVIEW_NAME.matcher(name);
                String locale = m.matches() ? m.group(1) : "en_US";
                if (!themePrev.containsKey(locale)) themePrev.put(locale, new ArrayList<String>());
                themePrev.get(locale).add(name);
            }
            if (themePrev.isEmpty()) themePrev.put("en_US", new ArrayList<String>());

            // Meta of each component
            for (Sub s : subs) {
                Map<String, List<String>> prev = new LinkedHashMap<>();
                for (Map.Entry<String, List<String>> le : themePrev.entrySet()) {
                    List<String> mine = new ArrayList<>();
                    String prefix = le.getKey() + "_" + s.code + "_";
                    for (String name : le.getValue()) if (name.startsWith(prefix)) mine.add(name);
                    prev.put(le.getKey(), mine);
                }
                List<Object> parents = new ArrayList<>();
                parents.add(ref(themeId, "theme"));
                Map<String, Object> meta = buildMeta(s.id, s.hash, s.size, info, prev, parents,
                        new ArrayList<Object>(), true);
                writeMeta(dataDir, s.code, s.id, meta);
            }

            // Main theme resource
            progress.onStep("Saving theme info...");
            File tdir = new File(dataDir, "content/theme");
            tdir.mkdirs();
            new FileOutputStream(new File(tdir, themeId + ".mrc")).close();
            List<Object> subRefs = new ArrayList<>();
            for (Sub s : subs) subRefs.add(ref(s.id, s.code));
            Map<String, Object> themeMeta = buildMeta(themeId, wholeHash, wholeSize, info, themePrev,
                    new ArrayList<Object>(), subRefs, false);
            writeMeta(dataDir, "theme", themeId, themeMeta);

            Result res = new Result();
            res.themeId = themeId;
            res.dataDir = dataDir;
            res.components = subs.size();
            return res;
        } finally {
            zf.close();
        }
    }

    // ---------- metadata ----------

    private static Map<String, Object> ref(String id, String code) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("localId", id);
        m.put("resourceCode", code);
        m.put("extraMeta", new LinkedHashMap<String, Object>());
        m.put("metaPath", null);
        m.put("contentPath", null);
        return m;
    }

    private static Map<String, Object> localized(Map<String, String> locales, String fallback, boolean fallbackFirst) {
        Map<String, Object> m = new LinkedHashMap<>();
        if (fallbackFirst) m.put("fallback", fallback);
        for (Map.Entry<String, String> e : locales.entrySet()) m.put(e.getKey(), e.getValue());
        if (!fallbackFirst) m.put("fallback", fallback);
        return m;
    }

    private static Map<String, Object> buildMeta(String id, String hash, long size, Info info,
                                                  Map<String, List<String>> prev, List<Object> parents,
                                                  List<Object> subs, boolean sub) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("localId", id);
        m.put("onlineId", null);
        m.put("assemblyId", null);
        m.put("productId", null);
        m.put("hash", hash);
        m.put("platform", info.platform);
        m.put("size", size);
        m.put("updatedTime", 0);
        m.put("version", info.version);
        boolean ff = sub; // sub-resources list "fallback" first, the main theme last
        m.put("authors", localized(info.authors, info.fallbackAuthor, ff));
        m.put("designers", localized(info.designers, info.fallbackDesigner, ff));
        m.put("titles", localized(info.titles, info.fallbackTitle, ff));
        m.put("descriptions", localized(info.descs, info.fallbackDesc, ff));
        Map<String, Object> thumbs = new LinkedHashMap<>();
        Map<String, Object> previews = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> e : prev.entrySet()) {
            thumbs.put(e.getKey(), new ArrayList<Object>(e.getValue()));
            previews.put(e.getKey(), new ArrayList<Object>(e.getValue()));
        }
        m.put("builtInThumbnails", thumbs);
        m.put("builtInPreviews", previews);
        m.put("thumbnails", new ArrayList<Object>());
        m.put("previews", new ArrayList<Object>());
        m.put("parentResources", parents);
        m.put("subResources", subs);
        m.put("extraMeta", new LinkedHashMap<String, Object>());
        m.put("metaPath", null);
        m.put("contentPath", null);
        m.put("rightsPath", null);
        m.put("screenRatio", null);
        m.put("supportHomeSearchBar", false);
        m.put("packageVersion", null);
        m.put("packageName", null);
        m.put("officialIcons", false);
        m.put("iconsCount", null);
        m.put("fontWeight", null);
        m.put("price", -1);
        m.put("isBackUpVersion", false);
        m.put("themeType", 0);
        m.put("miuiAdapterVersion", info.adapter);
        return m;
    }

    private static void writeMeta(File dataDir, String code, String id, Map<String, Object> meta) throws IOException {
        File dir = new File(dataDir, "meta/" + safe(code));
        dir.mkdirs();
        StringBuilder sb = new StringBuilder();
        writeJson(sb, meta, 0);
        try (OutputStream os = new FileOutputStream(new File(dir, id + ".mrm"))) {
            os.write(sb.toString().getBytes(StandardCharsets.UTF_8));
        }
    }

    // ---------- description.xml ----------

    private static Info parseInfo(InputStream in) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        Document doc = f.newDocumentBuilder().parse(in);
        Element root = doc.getDocumentElement();
        Info i = new Info();
        i.version = text(root, "version");
        String ui = text(root, "uiVersion");
        try { i.platform = ui == null ? null : Integer.valueOf(ui.trim()); } catch (NumberFormatException ignored) { }
        i.adapter = text(root, "miuiAdapterVersion");
        String a = text(root, "author"); if (a != null) i.fallbackAuthor = a;
        String d = text(root, "designer"); if (d != null) i.fallbackDesigner = d;
        String t = text(root, "title"); if (t != null) i.fallbackTitle = t;
        String s = text(root, "description"); if (s != null) i.fallbackDesc = s;
        locales(root, "authors", "author", i.authors);
        locales(root, "designers", "designer", i.designers);
        locales(root, "titles", "title", i.titles);
        locales(root, "descriptions", "description", i.descs);
        return i;
    }

    private static String text(Element parent, String tag) {
        for (Node n = parent.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element && ((Element) n).getTagName().equals(tag)) return n.getTextContent();
        }
        return null;
    }

    private static void locales(Element root, String group, String item, Map<String, String> out) {
        for (Node n = root.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n instanceof Element && ((Element) n).getTagName().equals(group)) {
                NodeList list = ((Element) n).getElementsByTagName(item);
                for (int k = 0; k < list.getLength(); k++) {
                    Element e = (Element) list.item(k);
                    String loc = e.getAttribute("locale");
                    if (loc != null && !loc.isEmpty()) out.put(loc, e.getTextContent());
                }
            }
        }
    }

    // ---------- helpers ----------

    private static Comparator<String> orderComparator(final String[] order) {
        return new Comparator<String>() {
            int idx(String s) {
                for (int i = 0; i < order.length; i++) if (order[i].equals(s)) return i;
                return order.length;
            }
            @Override public int compare(String a, String b) {
                int c = Integer.compare(idx(a), idx(b));
                return c != 0 ? c : a.compareTo(b);
            }
        };
    }

    private static Comparator<String> previewComparator() {
        return new Comparator<String>() {
            int idx(String name) {
                Matcher m = PREVIEW_NAME.matcher(name);
                String rest = m.matches() ? m.group(2) : name;
                for (int i = 0; i < PREVIEW_ORDER.length; i++) {
                    if (rest.startsWith(PREVIEW_ORDER[i] + "_")) return i;
                }
                return PREVIEW_ORDER.length;
            }
            @Override public int compare(String a, String b) {
                int c = Integer.compare(idx(a), idx(b));
                return c != 0 ? c : a.compareTo(b);
            }
        };
    }

    private static String safe(String s) { return s.replaceAll("[\\\\/:*?\"<>|]", "_"); }

    private static String sha1(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) > 0) md.update(buf, 0, r);
        }
        return hex(md.digest());
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    // ---------- JSON (pretty, 2 spaces, insertion order) ----------

    @SuppressWarnings("unchecked")
    private static void writeJson(StringBuilder sb, Object v, int level) {
        if (v == null) {
            sb.append("null");
        } else if (v instanceof String) {
            quote(sb, (String) v);
        } else if (v instanceof Number || v instanceof Boolean) {
            sb.append(v.toString());
        } else if (v instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) v;
            if (m.isEmpty()) { sb.append("{}"); return; }
            sb.append("{\n");
            int n = 0;
            for (Map.Entry<String, Object> e : m.entrySet()) {
                indent(sb, level + 1);
                quote(sb, e.getKey());
                sb.append(": ");
                writeJson(sb, e.getValue(), level + 1);
                if (++n < m.size()) sb.append(',');
                sb.append('\n');
            }
            indent(sb, level);
            sb.append('}');
        } else if (v instanceof List) {
            List<Object> l = (List<Object>) v;
            if (l.isEmpty()) { sb.append("[]"); return; }
            sb.append("[\n");
            for (int i = 0; i < l.size(); i++) {
                indent(sb, level + 1);
                writeJson(sb, l.get(i), level + 1);
                if (i < l.size() - 1) sb.append(',');
                sb.append('\n');
            }
            indent(sb, level);
            sb.append(']');
        } else {
            quote(sb, v.toString());
        }
    }

    private static void indent(StringBuilder sb, int level) {
        for (int i = 0; i < level; i++) sb.append("  ");
    }

    private static void quote(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
    }
}
