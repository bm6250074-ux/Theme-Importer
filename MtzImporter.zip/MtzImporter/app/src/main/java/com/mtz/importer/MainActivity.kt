package com.mtz.importer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private val pickCode = 1001
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.WHITE)
        }
        val button = Button(this).apply {
            text = "Import"
            textSize = 20f
            setOnClickListener { pickFile() }
        }
        status = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad, 0, 0)
        }
        root.addView(button, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        status.text = "Importing..."
        Thread {
            val msg = try {
                "Saved to:\n" + saveTheme(uri)
            } catch (e: Exception) {
                "Failed: " + e.message
            }
            runOnUiThread { status.text = msg }
        }.start()
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
        }
        return "theme_" + System.currentTimeMillis() + ".mtz"
    }

    // Saves into: Android/data/com.android.thememanages/files/MIUI/theme/
    private fun saveTheme(uri: Uri): String {
        val base = getExternalFilesDir(null) ?: throw IllegalStateException("Storage unavailable")
        val dir = File(base, "MIUI/theme").apply { mkdirs() }
        val out = File(dir, displayName(uri).replace('/', '_'))
        contentResolver.openInputStream(uri)!!.use { input ->
            out.outputStream().use { input.copyTo(it) }
        }
        return out.absolutePath
    }
}
