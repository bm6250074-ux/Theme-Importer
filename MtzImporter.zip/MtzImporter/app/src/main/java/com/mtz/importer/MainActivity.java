package com.mtz.importer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int PICK_CODE = 1001;
    private TextView status;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.WHITE);

        button = new Button(this);
        button.setText("Import");
        button.setTextSize(20f);
        button.setOnClickListener(v -> pickFile());

        status = new TextView(this);
        status.setGravity(Gravity.CENTER);
        status.setTextSize(14f);
        status.setTextColor(Color.DKGRAY);
        status.setPadding(0, pad, 0, 0);

        root.addView(button, new LinearLayout.LayoutParams(-1, -2));
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_CODE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        button.setEnabled(false);
        status.setText("Importing...");
        new Thread(() -> {
            String msg;
            File tmp = new File(getCacheDir(), "import_" + System.currentTimeMillis() + ".mtz");
            try {
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(tmp)) {
                    if (in == null) throw new IllegalStateException("Cannot open the file");
                    byte[] buf = new byte[65536];
                    int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                }
                File base = getExternalFilesDir(null);
                if (base == null) throw new IllegalStateException("Storage unavailable");
                File themeRoot = new File(base, "MIUI/theme");
                themeRoot.mkdirs();
                MtzConverter.Result res = MtzConverter.convert(tmp, themeRoot, step ->
                        runOnUiThread(() -> status.setText(step)));
                msg = "Done (" + res.components + " components)\n\nSaved to:\n" + res.dataDir.getAbsolutePath();
            } catch (Throwable e) {
                msg = "Failed: " + e.getMessage();
            } finally {
                tmp.delete();
            }
            final String shown = msg;
            runOnUiThread(() -> {
                status.setText(shown);
                button.setEnabled(true);
            });
        }).start();
    }
}
